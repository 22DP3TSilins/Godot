using Godot;
using System;

public partial class StartButton : Button
{
void _on_pressed()
{
	GetTree().ChangeSceneToFile("res://Scines/Levels/game.tscn");
}
}

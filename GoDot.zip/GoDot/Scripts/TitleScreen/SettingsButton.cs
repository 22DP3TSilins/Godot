using Godot;
using System;

public partial class SettingsButton : Button
{
void _on_pressed()
{
	GetTree().ChangeSceneToFile("res://Scines/Levels/TitleScreenUi.tscn");
}
}

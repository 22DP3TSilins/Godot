using Godot;
using System;

public partial class SaveButton : Button
{
void _on_pressed()
{
	GetTree().ChangeSceneToFile("res://Scines/Levels/game.tscn");
}
}




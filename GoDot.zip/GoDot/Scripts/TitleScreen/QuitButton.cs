using Godot;
using System;

public partial class QuitButton : Button
{
void _on_pressed()
{
	GetTree().Quit();
}
}
